# Nanocore-Rat
Nanocore rat download

-Download the file and put it into a folder.
-Make sure that your anti virus doesn't block it.
-Then load it up, build your own rat. Have fun!
